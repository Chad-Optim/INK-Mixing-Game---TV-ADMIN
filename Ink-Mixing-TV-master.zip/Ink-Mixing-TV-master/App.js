

import React, { useEffect, useState } from 'react';
import { LogBox } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Dashboard from './src/screens/Dashboard';
import ResultScreen from './src/screens/ResultScreen';
import ResultLandingScreen from './src/screens/ResultLandingScreen';
import CountdownScreen from './src/screens/CountdownScreen';
import TeamDefine from './src/screens/TeamDefine';
import Sound from 'react-native-sound';
import { firebase } from '@react-native-firebase/database';
import { FIREBASE_URL } from './Constant';

LogBox.ignoreAllLogs();


const Stack = createNativeStackNavigator();

const App = () => {
  const [EndDateTime, setEndDateTime] = useState();
  var db = firebase
    .app()
    .database(FIREBASE_URL)


  useEffect(() => {
    db.ref('game/1/Endtime').on('value', (data) => {
      var Endtime = data.val();
      var EndtimeVal = new Date(Endtime);
      setEndDateTime(EndtimeVal);
      if (EndDateTime != EndtimeVal && EndtimeVal < new Date(Date.now())) {
        const countdownSound = new Sound(require("./src/assets/sounds/countdown3.wav"), (error) => {
          if (error) {
            return;
          }
          global.sound = countdownSound;
        });
      }
    });

  }, [])

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="CountDown"
          component={CountdownScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Dashboard"
          component={Dashboard}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ResultScreen"
          component={ResultScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ResultLandingScreen"
          component={ResultLandingScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="TeamDefine"
          component={TeamDefine}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
