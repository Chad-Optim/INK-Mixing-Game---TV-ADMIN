import { firebase } from "@react-native-firebase/database";
import { FIREBASE_URL } from "./Constant";

export const db = firebase
    .app()
    .database(FIREBASE_URL)