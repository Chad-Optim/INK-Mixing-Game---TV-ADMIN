import { View, SafeAreaView, StyleSheet, Dimensions, Pressable, Alert, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import LottieView from 'lottie-react-native';
import { backgroundColor, textPrimaryColor } from '../utils/colors'
import { firebase } from '@react-native-firebase/database';
import { Text } from '../component/Text'
import { FIREBASE_URL } from '../../Constant';

const { height } = Dimensions.get('screen')

const RESULT_WIDTH = height / 3

const Result = ({ player, score, winingTitle, note, matchedColor, userColor }) => (
  <View style={styles.resultContent}>
    <View style={[styles.result, userColor && { backgroundColor: userColor }]}>
      <View style={[styles.resultDot, matchedColor && { backgroundColor: matchedColor }]} />
      <Text style={styles.resultText}>{score}%</Text>
    </View>
    <View style={styles.textContent}>
      <Text style={styles.player}>{player}</Text>
      <View style={styles.hr} />
      <Text style={styles.winningTitle}>{winingTitle}</Text>
    </View>
    <View style={styles.noteContent}>
      <Text style={styles.note}>You scored {score}%.</Text>
      <Text style={styles.note}>{note} </Text>
    </View>
  </View>
)

const ResultScreen = ({ navigation }) => {

  const [marks, setMarks] = useState({
    player1: '',
    player2: '',
    player3: ''
  })
  const [color, setColor] = useState('')
  const [playerColors, setPlayerColors] = useState({
    player1: '',
    player2: '',
    player3: ''
  })
  const fApp = firebase
    .app()
    .database(FIREBASE_URL)
    .ref('/game/1/')

  useEffect(() => {
    fApp.on('value', (data) => {
      var red = data.child("r").val()
      var green = data.child("g").val()
      var blue = data.child("b").val()
      var users = data.child("users").val();
      var loop = data.child("loop").val();
      setColor(`rgb(${red},${green},${blue})`)
      var marskObj = {};
      var playerColor = {};
      if (users) {
        Object.values(users).forEach((user, i) => {
          if (user.r == 0 && user.g == 0 && user.b == 0) {
            marskObj['player' + (i + 1)] = 0;
          } else {
            var rDiff = ((255 - Math.abs(red - user.r)) / 255) * 100
            var gDiff = ((255 - Math.abs(green - user.g)) / 255) * 100
            var bDiff = ((255 - Math.abs(blue - user.b)) / 255) * 100;
            marskObj['player' + (i + 1)] = Math.floor((rDiff + gDiff + bDiff) / 3);
          }
          playerColor['player' + (i + 1)] = `rgb(${user.r},${user.g},${user.b})`;
        })
        setMarks(marskObj);
        setPlayerColors(playerColor);
        var dateEnd = new Date(Date.now());
        dateEnd.setSeconds(dateEnd.getSeconds() + 21);
      }
    })
    var timout = setTimeout(() => {
      fApp.update({
        r: Math.floor(Math.random() * 155) + 100,
        g: Math.floor(Math.random() * 155) + 100,
        b: Math.floor(Math.random() * 155) + 100,
        a: 1,
        users: [],
        Endtime: null,
        status: null
      })
        .then(() => {
          if (global.sound) global.sound.stop();
          clearTimeout(timout);
          navigation.navigate("CountDown", { time: new Date(Date.now()) });
        });
    }, 4500)
  }, [])

  const showTitle = (mark) => {
    let text = ''
    if (mark > 90) text = 'Superstar!'
    else if (mark > 75) text = 'Amazing'
    else if (mark > 50) text = 'Getting Closer'
    else if (mark > 0) text = 'Nice Try'
    return text;
  }

  const showNote = (mark) => {
    let text = ''
    if (mark > 90) text = "You're a colour mixing master"
    else if (mark > 75) text = 'That was very close, great work'
    else if (mark > 50) text = 'Nice work!'
    else if (mark > 0) text = 'Nice work!'
    return text;
  }
  const endGameFunc = () => {
    if (global.sound) global.sound.stop();
    fApp.update({
      loop: null,
      Endtime: null,
      status: null
    })
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.resultContainer}>
        <Result
          score={marks.player1 ? marks.player1 : 0}
          player="Player 1"
          winingTitle={showTitle(marks.player1)}
          note={showNote(marks.player1)}
          matchedColor={color}
          userColor={playerColors.player1}
        />
        <Result
          score={marks.player2 ? marks.player2 : 0}
          player="Player 2"
          winingTitle={showTitle(marks.player2)}
          note={showNote(marks.player2)}
          matchedColor={color}
          userColor={playerColors.player2}
        />
        <Result
          score={marks.player3 ? marks.player3 : 0}
          player="Player 3"
          winingTitle={showTitle(marks.player3)}
          note={showNote(marks.player3)}
          matchedColor={color}
          userColor={playerColors.player3}
        />
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={() => endGameFunc()} style={styles.button}>
          <Text style={[styles.startText, { fontSize: 24 }]}>Stop</Text>
        </TouchableOpacity>
      </View>
      <LottieView source={require('../animations/result.json')} autoPlay loop />
    </SafeAreaView>
  )
}

export default ResultScreen

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
  },
  buttonContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    // height: 100,
    marginBottom: 10,
    zIndex: 2000
  },
  resultContainer: {
    marginTop: height / 5,
    flex: 1,
    flexDirection: 'row',
  },
  resultContent: {
    flex: 1,
    width: RESULT_WIDTH,
    alignItems: 'center'
  },
  result: {
    backgroundColor: 'rgba(225,94,120,255)',
    height: RESULT_WIDTH,
    width: RESULT_WIDTH,
    borderRadius: RESULT_WIDTH / 2,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center'
  },
  startText: {
    color: '#ffffff',
    fontSize: 32,
    fontWeight: '700',
    textAlign: 'center'
  },
  resultDot: {
    backgroundColor: 'rgba(225,94,120,255)',
    height: RESULT_WIDTH / 2 - 20,
    width: RESULT_WIDTH / 2 - 20,
    borderRadius: RESULT_WIDTH / 4,
    borderWidth: 5,
    position: 'absolute',
    top: -30,
    right: -30
  },
  resultText: {
    color: textPrimaryColor,
    fontSize: 90,
    fontWeight: '500',
    textAlign: 'center'
  },
  textContent: {
    marginTop: 30,
    width: RESULT_WIDTH
  },
  player: {
    color: textPrimaryColor,
    fontSize: 28,
    fontWeight: '700',
  },
  hr: {
    marginTop: 10,
    height: 2,
    backgroundColor: '#ffff'
  },
  winningTitle: {
    marginTop: 15,
    color: textPrimaryColor,
    fontSize: 42,
    fontWeight: '900',
  },
  noteContent: {
    marginTop: 20,
    borderLeftWidth: 5,
    borderLeftColor: '#ffff',
    width: RESULT_WIDTH,
    paddingLeft: 20
  },
  note: {
    color: textPrimaryColor,
    fontSize: 20,
    fontWeight: '700',
    textShadowColor: '#232323',
    textShadowOffset: { width: 10, height: 10 }
  },
  button: {
    padding: 10,
    // paddingHorizontal: 50,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: '#ffff',
    width: 200,
    zIndex: 2000
  }
})