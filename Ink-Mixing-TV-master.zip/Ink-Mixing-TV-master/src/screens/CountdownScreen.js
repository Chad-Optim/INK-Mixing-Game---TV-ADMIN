import { View, SafeAreaView, StyleSheet, AppState } from 'react-native'
import React, { useEffect, useState } from 'react'
import { backgroundColor, textPrimaryColor } from '../utils/colors'
import { firebase } from '@react-native-firebase/database';
import LottieView from 'lottie-react-native';
import { Text } from '../component/Text'
import { FIREBASE_URL } from '../../Constant';

const LottieContainer = ({}) => {
  return <LottieView source={require('../animations/comp2_tv.json')} autoPlay loop />;
}

const CountdownScreen = ({ navigation, route }) => {
  const [time, setTime] = useState(null);
  const [started, setStarted] = useState(false);
  const [color, setColor] = useState({});
  const [dateTime, setDateTime] = useState("");
  var db = firebase
    .app()
    .database(FIREBASE_URL);

  useEffect(() => {
    AppState.addEventListener('change', state => {
      if (state === 'background' || state === 'inactive') {
        db.ref('/game/1/').update({
          loop: null,
          Endtime: null,
          users: null,
          status: null
        }).then(() => {
          navigation.navigate("CountDown")
        })
      }
    });
  }, [])

  useEffect(() => {
    setDateTime(route?.params?.time);
    var intervalObj = null;
    var refEntime = db.ref('game/1/Endtime').on('value', (data) => {
      var Endtime = data.val();
      if (Endtime) {
        db.ref('game/1/Endtime').off()
        var EndtimeVal = new Date(Endtime);
        db.ref('game/1').update({ status: true })
        setStarted(true);
        if (global.sound) global.sound.play();
        var currentTIme = new Date(Date.now());
        var minDef = Math.floor((EndtimeVal - currentTIme - 31) / 1000);
        setTime(minDef);
        var timerCompare = setTimeout(() => {
          intervalObj = setInterval(() => {
            setTime(prVal => {
              if (prVal > 2) {
                return prVal - 1;
              } else if (prVal == 2) {
                clearInterval(intervalObj);
                return prVal - 1;
              } else {
                clearInterval(intervalObj);
                return null;
              }
            });
          }, 1000);
          if (minDef > -1) {
            var timeout = setTimeout(() => {
              clearInterval(intervalObj);
              clearTimeout(timeout);
              setTime(null)
              navigation.navigate("Dashboard")
            }, minDef * 1000);
          }
          clearTimeout(timerCompare);
        }, Math.floor((((EndtimeVal - currentTIme - 31) / 1000) - minDef) * 1000))
      }
    });;
    db.ref('game/1/').once('value', (data) => {
      setColor({
        r: data.child("r").val(),
        g: data.child("g").val(),
        b: data.child("b").val(),
        a: data.child("a").val(),
      });
    });
    return () => {
      setTime(null);
    }
  }, [dateTime != route?.params?.time])


  return (
    <SafeAreaView key={route?.params?.time} style={styles.safeContainer}>
      {
        time && time > -1 && time < 23 ?
          <View style={styles.container}>
            <LottieView source={require('../animations/start4.json')} autoPlay loop={false} />
            {time < 6 &&
              <View style={styles.colorPlateContainer}>
                <View style={styles.colorPlate}>
                  <View style={{
                    backgroundColor: `rgb(${color.r},${color.g},${color.b})`,
                    width: '100%',
                    height: '100%',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: 200,
                    marginLeft: 30
                  }}>
                    <Text style={styles.count}>{time}</Text>
                  </View>
                </View>
              </View>
            }
          </View>
          :
          <LottieContainer />
      }
    </SafeAreaView>
  )
}

export default CountdownScreen

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: backgroundColor
  },
  closeContainer: {
    height: 50,
    marginRight: 50
  },
  closeIcon: {
    color: textPrimaryColor,
    fontSize: 30,
    fontWeight: '800',
    textAlign: 'right'
  },
  main: {
    flex: 1,
    backgroundColor: backgroundColor,
  },
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    justifyContent: 'center',
    alignItems: 'center'
  },
  text: {
    color: textPrimaryColor,
    fontSize: 100,
    fontWeight: '800',
    textAlign: 'center'
  },
  startText: {
    color: textPrimaryColor,
    fontSize: 85,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 20
  },
  button: {
    padding: 20,
    paddingHorizontal: 50,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: '#ffff',
    marginTop: 100
  },
  colorPlateContainer: {
    width: "100%",
    padding: 30
  },
  colorPlate: {
    height: 400,
    width: 400,
    borderRadius: 200,
  },
  textContainer: {
    width: "50%",
    paddingTop: 70
  },
  title: {
    fontSize: 90,
    color: 'white',
    fontWeight: "900",
    marginBottom: 0,
    lineHeight: 100
  },
  subtitle: {
    fontSize: 25,
    color: 'white',
    fontWeight: "700"
  },
  subtitleContainer: {
    marginTop: 40,
    borderLeftColor: 'white',
    borderLeftWidth: 5,
    paddingLeft: 30
  },
  count: {
    color: textPrimaryColor,
    fontSize: 250,
    fontWeight: '600',
    marginTop: 50
  }
})