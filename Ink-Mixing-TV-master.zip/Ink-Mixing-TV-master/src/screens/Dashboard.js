import React, { useEffect, useState } from 'react';
import { View, TouchableOpacity, StyleSheet } from "react-native"
import { firebase } from '@react-native-firebase/database';
import PlayerCard from '../component/PlayerCard';
import CircularProgress from '../component/CircularProgress';
import { SafeAreaView } from 'react-native-safe-area-context';
import { backgroundColor } from '../utils/colors';
import Sound from 'react-native-sound'
import { Text } from '../component/Text'
import { FIREBASE_URL } from '../../Constant';

const Dashboard = ({ navigation, route }) => {
    const [color, setColor] = useState({});
    const [time, setTime] = useState(30);
    const [users, setUsers] = useState({});

    var db = firebase
        .app()
        .database(FIREBASE_URL)

    useEffect(() => {
        var intervalObj = setInterval(() => {
            setTime(prVal => {
                if (prVal > 0) {
                    return prVal - 1;
                } else {
                    clearInterval(intervalObj);
                    return null;
                }
            });

        }, 1000);
        var timeout = setTimeout(() => {
            clearTimeout(timeout);
            navigation.navigate("ResultScreen");
        }, 30000)
        db.ref('game/1/').once('value', (data) => {
            setColor({
                r: data.child("r").val(),
                g: data.child("g").val(),
                b: data.child("b").val(),
                a: data.child("a").val(),
            })
            var userList = data.child("users").val();
            setUsers(userList ? userList : {});
        });;

        db.ref('game/1/users/').on('child_added', (data) => {
            setUsers(userList => ({ ...userList, [data.key]: data.val() }));
        });

    }, [])

    return (
        <SafeAreaView style={styles.safeContainer}>
            <View style={styles.mainContainer}>
                <View style={styles.goalContent}>
                    <View>
                        <Text style={styles.colorTitle}>Your Goal</Text>
                        <View style={[
                            styles.goal,
                            { backgroundColor: `rgb(${color.r},${color.g},${color.b})` }
                        ]} />
                    </View>
                    <View style={styles.progress}>
                        <Text style={styles.colorTitle}>{' '}</Text>
                        <CircularProgress
                            percent={time * 100 / 30}
                            text={time}
                            ringColor={time > 10 ? 'white' : 'red'}
                            ringBgColor={'black'}
                            textFontColor={time > 10 ? 'white' : 'red'}
                            bgColor={'black'}
                        />
                    </View>
                </View>
                {(color.r || color.g || color.b) &&
                    <View style={styles.playerContainer}>
                        <PlayerCard key={Object.keys(users)[0]} id={Object.keys(users)[0]} index={0} color={color} />
                        <PlayerCard key={Object.keys(users)[1]} id={Object.keys(users)[1]} index={1} color={color} />
                        <PlayerCard key={Object.keys(users)[2]} id={Object.keys(users)[2]} index={2} color={color} />
                    </View>
                }
            </View>
        </SafeAreaView>
    );
};


const styles = StyleSheet.create({
    safeContainer: {
        backgroundColor: backgroundColor,
        flex: 1
    },
    playerContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-evenly',
    },
    mainContainer: {
        paddingVertical: 10,
        flex: 1,
    },
    goalContent: {
        flex: 1,
        padding: 20,
        paddingTop: 50,
        paddingBottom: 40,
        marginBottom: 40,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#ffff'
    },
    goal: {
        height: 200,
        width: 200,
        borderRadius: 200,
    },
    progress: {
        marginLeft: 100
    },
    colorTitle: {
        fontSize: 32,
        color: 'white',
        fontWeight: "700",
        textAlign: 'center',
        marginBottom: 20
    },
    textContainer: {
        width: "50%",
        height: 200,
        marginLeft: 50,
        paddingTop: 20,
        flexDirection: 'column',
        justifyContent: 'center'
    },
    title: {
        fontSize: 68,
        color: 'white',
        fontWeight: "900",
        marginTop: 40,
        lineHeight: 100
    }
})
export default Dashboard;