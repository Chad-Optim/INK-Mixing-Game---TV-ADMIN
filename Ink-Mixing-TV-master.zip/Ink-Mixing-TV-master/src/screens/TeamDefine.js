import { firebase } from '@react-native-firebase/database';
import React, { useEffect, useState } from 'react';
import { View, TouchableOpacity, StyleSheet } from "react-native"
import { FIREBASE_URL } from '../../Constant';
import { Text } from '../component/Text'


const TeamDefine = ({ navigation }) => {
    const [color, setColor] = useState({});
    useEffect(() => {
        var db = firebase
            .app()
            .database(FIREBASE_URL);

        db.ref('game/1/').once('value', (data) => {
            setColor({
                r: data.child("r").val(),
                g: data.child("g").val(),
                b: data.child("b").val(),
                a: data.child("a").val(),
            });
        })
        var timeOut = setTimeout(() => {
            clearTimeout(timeOut);
            navigation.navigate("Dashboard", {
                color: color
            })
        }, 5000);

    }, [])
    return (
        <View style={{ backgroundColor: 'black', flex: 1 }}>
            <View style={styles.mainContainer}>
                <View style={styles.container}>
                    <View style={styles.colorPlateContainer}>
                        <View style={styles.colorPlate}>
                            <View style={{ backgroundColor: `rgb(${color.r},${color.g},${color.b})`, borderRadius: 200, width: '100%', height: '100%' }}>

                            </View>
                        </View>
                    </View>
                    <View style={styles.textContainer}>
                        <Text style={styles.title}>Match this</Text>
                        <Text style={styles.title}>color!</Text>
                        <View style={styles.subtitleContainer}>
                            <Text style={styles.subtitle}>Take your stations at an iPad</Text>
                            <Text style={styles.subtitle}>and match this color by using</Text>
                            <Text style={styles.subtitle}>your RGB color slider!</Text>
                        </View>

                    </View>
                </View>
            </View>
        </View>
    );
};


const styles = StyleSheet.create({
    startText: {
        color: 'white',
        fontSize: 20
    },
    mainContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center'
    },
    container: {
        padding: 20,
        display: "flex",
        flexDirection: 'row',
        height: 500
    },
    colorPlateContainer: {
        width: "50%",
        flexDirection: 'row-reverse',
        padding: 30

    },
    colorPlate: {
        height: 400,
        width: 400,
        borderRadius: 200,
        overflow: 'hidden'
    },
    textContainer: {
        width: "50%",
        paddingTop: 70
    },
    title: {
        fontSize: 90,
        color: 'white',
        fontWeight: "900",
        marginBottom: 0,
        lineHeight: 100
    },
    subtitle: {
        fontSize: 25,
        color: 'white',
        fontWeight: "700"
    },
    subtitleContainer: {
        marginTop: 40,
        borderLeftColor: 'white',
        borderLeftWidth: 5,
        paddingLeft: 30
    }
})
export default TeamDefine;