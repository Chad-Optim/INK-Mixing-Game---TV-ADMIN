import { View, SafeAreaView, StyleSheet } from 'react-native'
import React, { useEffect } from 'react'
import { backgroundColor, textPrimaryColor } from '../utils/colors'
import LottieView from 'lottie-react-native';
import { Text } from '../component/Text'

const ResultLandingScreen = ({ navigation }) => {
  useEffect(() => {
    var timeout = setTimeout(() => {
      clearTimeout(timeout);
      navigation.navigate("ResultScreen");
    }, 2000)
  }, [])
  return (
    <SafeAreaView style={styles.container}>
      <LottieView source={require('../animations/comp2.json')} autoPlay loop />
      <Text style={styles.text}>Your results have just landed!</Text>
    </SafeAreaView>
  )
}

export default ResultLandingScreen

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: backgroundColor,
    justifyContent: 'center',
    alignItems: 'center'
  },
  text: {
    color: textPrimaryColor,
    fontSize: 100,
    fontWeight: '800',
    textAlign: 'center'
  }
})