export const backgroundColor = 'rgba(0,0,0,255)'
export const textPrimaryColor = 'rgba(255,255,255,255)'
