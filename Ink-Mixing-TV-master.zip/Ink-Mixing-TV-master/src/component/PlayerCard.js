import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Dimensions } from "react-native"
import { Slider } from 'react-native';
import { firebase } from '@react-native-firebase/database';
import { getUniqueId } from 'react-native-device-info';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import LinearGradient from 'react-native-linear-gradient';
import { Text } from './Text'
import { FIREBASE_URL } from '../../Constant';

const { height, width } = Dimensions.get('screen')

const PlayerCard = ({ color, id, index }) => {
    const [rColor, setRColor] = useState(0);
    const [gColor, setGColor] = useState(0);
    const [bColor, setBColor] = useState(0);
    var db = firebase
        .app()
        .database(FIREBASE_URL);

    useEffect(() => {
        db.ref('game/1/users/' + id)
            .on('value', (data) => {
                setGColor(data.child("g").val());
                setRColor(data.child("r").val());
                setBColor(data.child("b").val());
            })

    }, [id])

    return (
        <View key={id} style={styles.cardContainer}>
            <Text style={styles.title}>Player {index + 1}</Text>
            <View style={styles.card}>
                <View style={styles.container}>
                    <View>
                        <Text style={styles.text}>Your Goal</Text>
                        <View style={[
                            styles.colorBall,
                            { backgroundColor: `rgb(${color.r},${color.g},${color.b})` }
                        ]}
                        />
                    </View>
                    <View style={styles.line}>
                    </View>
                    <View>
                        <Text style={styles.text}>Your Colour</Text>
                        <View style={[
                            styles.colorBall,
                            {
                                backgroundColor: `rgb(${rColor},${gColor},${bColor})`,
                                borderColor: `rgb(${rColor + 50},${gColor + 50},${bColor + 50})`,
                            }
                        ]}>
                        </View>
                    </View>
                </View>
                <View style={styles.sliderContainer}>
                    <View style={styles.slider}>
                        <Text style={[styles.sliderText, { marginRight: 10, marginTop: 30 }]}>R</Text>
                        <View>
                            <LinearGradient
                                colors={[`rgb(${color.r},${color.g},${color.b})`, 'rgb(255,0,0)']}
                                start={{ x: 0, y: 0.5 }}
                                end={{ x: 1, y: 0.5 }}
                                style={styles.linearGradient}
                            />
                            <View style={{ marginTop: -20 }}>
                                <MultiSlider
                                    sliderLength={180}
                                    min={0}
                                    containerStyle={{
                                        zIndex: 2000,
                                        overflow: 'visible',
                                        position: 'absolute',
                                        marginTop: -15
                                    }}
                                    max={255}
                                    selectedStyle={{
                                        zIndex: 2000,
                                    }}
                                    trackStyle={{
                                        height: 10,
                                        borderRadius: 10,
                                        backgroundColor: 'transparent',
                                    }}
                                    markerStyle={{
                                        backgroundColor: 'red',
                                        top: 8,
                                        height: 18,
                                        width: 18,
                                        borderWidth: 1,
                                        borderColor: '#000'
                                    }}
                                    values={[rColor]}
                                />
                            </View>
                        </View>
                        <Text style={[styles.sliderText, { marginLeft: 10, textAlign: 'right', marginTop: 30 }]}>{rColor ? rColor : 0}</Text>
                    </View>
                    <View style={[styles.slider, { marginTop: -50 }]}>
                        <Text style={[styles.sliderText, { marginRight: 10, marginTop: 30 }]}>G</Text>
                        <View>
                            <LinearGradient
                                colors={['rgb(0,255,0)', `rgb(${color.r},${color.g},${color.b})`]}
                                start={{ x: 0, y: 0.5 }}
                                end={{ x: 1, y: 0.5 }}
                                style={styles.linearGradient}
                            />
                            <View style={styles.sliderMain}>
                                <MultiSlider
                                    sliderLength={180}
                                    min={0}
                                    containerStyle={{
                                        zIndex: 2000,
                                        overflow: 'visible',
                                        position: 'absolute',
                                        marginTop: -12
                                    }}
                                    max={255}
                                    selectedStyle={{
                                        zIndex: 2000,
                                    }}
                                    trackStyle={{
                                        height: 15,
                                        borderRadius: 10,
                                        backgroundColor: 'transparent'
                                    }}
                                    markerStyle={{
                                        backgroundColor: 'green',
                                        top: 8,
                                        height: 18,
                                        width: 18,
                                        borderWidth: 1,
                                        borderColor: '#000'
                                    }}
                                    values={[gColor]}

                                    isMarkersSeparated={true}
                                />
                            </View>
                        </View>
                        <Text style={[styles.sliderText, { marginLeft: 10, textAlign: 'right', marginTop: 30 }]}>{gColor ? gColor : 0}</Text>
                    </View>
                    <View style={[styles.slider, { marginTop: -50 }]}>
                        <Text style={[styles.sliderText, { marginRight: 10, marginTop: 30 }]}>B</Text>
                        <View>
                            <LinearGradient
                                colors={['rgb(0,0,255)', `rgb(${color.r},${color.g},${color.b})`]}
                                start={{ x: 0, y: 0.5 }}
                                end={{ x: 1, y: 0.5 }}
                                style={styles.linearGradient}
                            />
                            <View style={{ marginTop: -20 }}>
                                <MultiSlider
                                    sliderLength={180}
                                    min={0}
                                    containerStyle={{
                                        zIndex: 2000,
                                        overflow: 'visible',
                                        position: 'absolute',
                                        marginTop: -11
                                    }}
                                    max={255}
                                    selectedStyle={{
                                        zIndex: 2000,
                                    }}
                                    trackStyle={{
                                        height: 15,
                                        borderRadius: 10,
                                        backgroundColor: 'transparent'
                                    }}
                                    markerStyle={{
                                        backgroundColor: 'blue',
                                        top: 8,
                                        height: 18,
                                        width: 18,
                                        borderWidth: 1,
                                        borderColor: '#fffff'
                                    }}
                                    values={[bColor]}
                                    isMarkersSeparated={true}
                                />
                            </View>
                        </View>
                        <Text style={[styles.sliderText, { marginLeft: 10, textAlign: 'right', marginTop: 30 }]}>{bColor ? bColor : 0}</Text>
                    </View>
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    cardContainer: {
        flex: 1,
        width: width / 3,
        height: width / 3 - 50,
        paddingHorizontal: 10
    },
    sliderContainer: {
        width: width / 3,
        paddingLeft: 10,
        paddingRight: 30,
        paddingBottom: 20,
        height: 200,
    },
    sliderMain: {
        marginTop: -20
    },
    timeContainer: {
        padding: 30,
        paddingLeft: 50,
        paddingTop: 70,
        marginLeft: 30
    },
    linearGradient: {
        width: 180,
        height: 10,
        borderRadius: 20,
        marginTop: 15,
        zIndex: 0
    },
    title: {
        color: 'white',
        fontSize: 26,
        fontWeight: '700',
        textAlign: 'center',
        marginBottom: 25
    },
    text: {
        color: 'white',
        fontSize: 16,
        textAlign: 'center',
        fontWeight: '700',
        marginBottom: 5
    },
    line: {
        borderLeftColor: 'gray',
        borderLeftWidth: 1,
        width: 20,
        marginLeft: 20,
        height: 180
    },
    colorBall: {
        width: 140,
        height: 140,
        borderRadius: 100,
        borderWidth: 1
    },
    container: {
        flex: 1,
        flexDirection: 'row',
        padding: 20,
        justifyContent: 'space-evenly'
    },
    card: {
        borderWidth: 3,
        borderColor: '#ffff',
        borderRadius: 15,
        width: "100%",
        height: "100%",
    },
    sliderText: {
        color: '#fff',
        // marginHorizontal: 5,
        width: 30
    },
    slider: {
        flex: 1,
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: 10,
        paddingHorizontal: 30,
        marginTop: (height / 10) - 20
    }
})

export default PlayerCard;