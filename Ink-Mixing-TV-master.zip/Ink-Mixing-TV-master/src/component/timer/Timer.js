import React, { useEffect, useState } from 'react';
import { View } from 'react-native'
import { Text } from '../Text'

const Timer = ({ }) => {
    const [time, setTime] = useState(40);
    useEffect(() => {
        var intervalObj = setInterval(() => {
            clearInterval(intervalObj);
            setTime(prVal => prVal - 1);
        }, 1000);

    }, [])
    return (
        <View>
            <Text style={{ color: "white" }}>{time}</Text>
        </View>
    );
};

export default Timer;