export const FIREBASE_URL = "https://inkmixing-b0999-default-rtdb.asia-southeast1.firebasedatabase.app/"
//export const FIREBASE_URL = 'https://ink-mixing-game-default-rtdb.asia-southeast1.firebasedatabase.app/'
